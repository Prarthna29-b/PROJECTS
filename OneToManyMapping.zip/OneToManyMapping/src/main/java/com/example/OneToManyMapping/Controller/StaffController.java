package com.example.OneToManyMapping.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.OneToManyMapping.Entity.Staff;
import com.example.OneToManyMapping.Repository.StaffRepository;

@RestController
@RequestMapping(value = "/staff")
public class StaffController {
	@Autowired
    StaffRepository staffRepository;
    @ResponseBody
    @RequestMapping(value = "/staffs")
    public List<Staff> getOrderDetails() {
        List<Staff> staffresponse = (List<Staff>) staffRepository.findAll();
        return staffresponse;
    }
}
