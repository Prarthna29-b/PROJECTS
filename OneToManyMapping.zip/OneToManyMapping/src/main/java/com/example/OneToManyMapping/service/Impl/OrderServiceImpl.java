package com.example.OneToManyMapping.service.Impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.OneToManyMapping.Entity.Order;
import com.example.OneToManyMapping.Entity.Staff;
import com.example.OneToManyMapping.Repository.OrderRepository;
import com.example.OneToManyMapping.service.OrderService;

@Service
public   class OrderServiceImpl implements OrderService {
	@Autowired
    private OrderRepository orderRepository;
    public Order saveOrder(Order order) {
        List<Staff> staffList = new ArrayList<>();
       
        Staff staff1 = new Staff();
        staff1.setStaffname("Anuj");
       
        Staff staff2 = new Staff();
        staff2.setStaffname("Prarthna");
        
        Staff staff3 = new Staff();
        staff3.setStaffname("riya");
        
        staffList.add(staff1);
        staffList.add(staff2);
        staffList.add(staff3);
       
        staff1.setOrder(order);
        staff2.setOrder(order);
        staff3.setOrder(order);
        order.setStaffList(staffList);
        order = orderRepository.save(order);
        return order;
    }
    public Order findByOrderid(int orderid) {
        Order order = orderRepository.findByOrderid(orderid);
        return order;
    }
    public Order deleteByOrderid(int orderid) {
        Order order = orderRepository.deleteByOrderid(orderid);
        return order;
    }
}
