package com.entityTest.TestContainer;

import com.entityTest.TestContainer.entity.Student;
import com.entityTest.TestContainer.repository.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl{

    private  StudentRepo studentRepo;

    public StudentServiceImpl(StudentRepo studentRepo) {
        this.studentRepo= studentRepo;
    }

    public Student createStudent(){
        Student student = new Student(1,"rajat","mechanical");

       Student student1 = studentRepo.save(student);

        return student1;
    }
}
