package com.entityTest.TestContainer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestContainerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestContainerApplication.class, args);
	}

}
