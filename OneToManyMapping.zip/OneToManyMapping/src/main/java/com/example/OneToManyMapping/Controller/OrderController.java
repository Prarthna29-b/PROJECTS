package com.example.OneToManyMapping.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.OneToManyMapping.Entity.Order;
import com.example.OneToManyMapping.service.OrderService;

@RestController
@RequestMapping(value = "/orderDetails")
public class OrderController {
	 @Autowired
	    private OrderService orderService;
	    @RequestMapping(value = "/saveorder", method = RequestMethod.POST)
	    @ResponseBody
	    public Order saveOrder(@RequestBody Order order) {
	        Order orderResponse = orderService.saveOrder(order);
	        return orderResponse;
	    }
	    @RequestMapping(value = "/{orderid}", method = RequestMethod.GET)
	    @ResponseBody
	    public Order getOrderDetails(@PathVariable int orderid) {
	        Order orderResponse = orderService.findByOrderid(orderid);
	        return orderResponse;
	    }
	    @RequestMapping(value = "/{orderid}", method = RequestMethod.DELETE)
	    @ResponseBody
	    public Order deleteOrderDetails(@PathVariable int orderid) {
	        Order orderResponse = orderService.deleteByOrderid(orderid);
	        return orderResponse;
	    }
}
