package com.example.OneToManyMapping.service;

import com.example.OneToManyMapping.Entity.Order;

public interface OrderService {
	public Order saveOrder(Order order);
    public Order findByOrderid(int orderid);
	public Order deleteByOrderid(int orderid);
    
}
