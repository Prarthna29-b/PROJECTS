package com.entityTest.TestContainer.connectionDetails;

import org.springframework.boot.autoconfigure.jdbc.JdbcConnectionDetails;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
class MyConnectionDetailsConfiguration {

    @Bean
    JdbcConnectionDetails myJdbcConnectionDetails() {
        return new JdbcConnectionDetails() {

            @Override
            public String getUsername() {
                return "sa";
            }

            @Override
            public String getPassword() {
                return "jungle";
            }

            @Override
            public String getJdbcUrl() {
                return "jdbc:sqlserver://localhost:1433;encrypt=true;trustServerCertificate=true;databaseName=RBAC17";
            }

            @Override
            public String getDriverClassName(){
                return "com.microsoft.sqlserver.jdbc.SQLServerDriver";
            }

        };
    }
}
